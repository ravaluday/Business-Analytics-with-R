Cleaned finance datasets for R

Files included
1. personal_transactions_cleaned.csv
2. finance_budget_actual_wide_cleaned.csv
3. finance_budget_actual_long_cleaned.csv
4. income_cleaned_ready.csv
5. expenses_cleaned_ready.csv
6. cashflow_combined_ready.csv
7. accounting_data_cleaned_ready.csv
8. cleaning_summary.csv

Key cleaning steps
- Standardized column names to snake_case
- Standardized date formats to YYYY-MM-DD (and YYYY-MM-DD HH:MM:SS where time was present)
- Standardized categorical text formatting
- Standardized currency text to uppercase
- Removed exact duplicates from the expense file
- Removed zero-amount expense rows
- Corrected misspelled finance workbook columns:
  operatinal_costs -> operational_costs
  travelling_cost -> travel_cost
  expenses -> scenario
- Added IDs and helper fields such as month and flow_type where useful

Recommended project usage
- expense/income agent logic: use cashflow_combined_ready.csv
- budget vs actual comparisons: use finance_budget_actual_long_cleaned.csv
- broader accounting analysis: use accounting_data_cleaned_ready.csv
- original personal transaction spending patterns: use personal_transactions_cleaned.csv